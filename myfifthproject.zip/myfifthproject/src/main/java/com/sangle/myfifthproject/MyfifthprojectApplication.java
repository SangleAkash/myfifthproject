package com.sangle.myfifthproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfifthprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfifthprojectApplication.class, args);
	}

}
