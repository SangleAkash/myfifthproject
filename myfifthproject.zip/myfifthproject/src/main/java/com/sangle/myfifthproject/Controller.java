package com.sangle.myfifthproject;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	@RequestMapping("/abc")
	ArrayList<Student> getStudentData() {
		ArrayList<Student> stulist = new ArrayList<>();
		Student student = new Student();
		student.setName("sangle akash");
		student.setRollno(1);
		student.getName();
		student.getRollno();
//		student.setName("sangle bhushan");
//		student.setRollno(2);
//		stulist.add(student);
		return stulist;
	}
}
