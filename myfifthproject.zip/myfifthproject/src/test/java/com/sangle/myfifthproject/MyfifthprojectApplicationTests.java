package com.sangle.myfifthproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfifthprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
